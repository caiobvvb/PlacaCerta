class PlatePhoto {
  final String id;
  final String plateNumber;
  final String imagePath;
  final DateTime timestamp;
  final bool isUploaded;
  final bool isSavedLocally;
  final String? driveFileId;

  PlatePhoto({
    required this.id,
    required this.plateNumber,
    required this.imagePath,
    required this.timestamp,
    this.isUploaded = false,
    this.isSavedLocally = false,
    this.driveFileId,
  });

  PlatePhoto copyWith({
    String? id,
    String? plateNumber,
    String? imagePath,
    DateTime? timestamp,
    bool? isUploaded,
    bool? isSavedLocally,
    String? driveFileId,
  }) {
    return PlatePhoto(
      id: id ?? this.id,
      plateNumber: plateNumber ?? this.plateNumber,
      imagePath: imagePath ?? this.imagePath,
      timestamp: timestamp ?? this.timestamp,
      isUploaded: isUploaded ?? this.isUploaded,
      isSavedLocally: isSavedLocally ?? this.isSavedLocally,
      driveFileId: driveFileId ?? this.driveFileId,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'plateNumber': plateNumber,
      'imagePath': imagePath,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'isUploaded': isUploaded,
      'isSavedLocally': isSavedLocally,
      'driveFileId': driveFileId,
    };
  }

  factory PlatePhoto.fromJson(Map<String, dynamic> json) {
    return PlatePhoto(
      id: json['id'],
      plateNumber: json['plateNumber'],
      imagePath: json['imagePath'],
      timestamp: DateTime.fromMillisecondsSinceEpoch(json['timestamp']),
      isUploaded: json['isUploaded'] ?? false,
      isSavedLocally: json['isSavedLocally'] ?? false,
      driveFileId: json['driveFileId'],
    );
  }

  /// Create PlatePhoto from Supabase data format
  factory PlatePhoto.fromSupabase(Map<String, dynamic> json) {
    return PlatePhoto(
      id: json['id'],
      plateNumber: json['plate_number'],
      imagePath: json['image_path'],
      timestamp: DateTime.parse(json['captured_at']),
      isUploaded: json['is_uploaded'] ?? false,
      isSavedLocally: json['is_saved_locally'] ?? false,
      driveFileId: json['drive_file_id'],
    );
  }

  /// Convert to Supabase format
  Map<String, dynamic> toSupabase() {
    return {
      'id': id,
      'plate_number': plateNumber,
      'image_path': imagePath,
      'captured_at': timestamp.toIso8601String(),
      'is_uploaded': isUploaded,
      'is_saved_locally': isSavedLocally,
      'drive_file_id': driveFileId,
    };
  }
}