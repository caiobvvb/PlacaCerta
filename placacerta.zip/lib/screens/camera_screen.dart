import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:placacerta/services/camera_service.dart';
import 'package:placacerta/services/storage_service.dart';
import 'package:placacerta/utils/constants.dart';

class CameraScreen extends StatefulWidget {
  final String plateNumber;

  const CameraScreen({
    super.key,
    required this.plateNumber,
  });

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with TickerProviderStateMixin {
  final CameraService _cameraService = CameraService();
  final StorageService _storageService = StorageService();
  
  bool _isInitialized = false;
  bool _isTakingPhoto = false;
  String? _errorMessage;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late AnimationController _flashAnimationController;
  late Animation<double> _flashAnimation;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    
    _animationController = AnimationController(
      duration: AppConstants.fastAnimation,
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    
    _flashAnimationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _flashAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_flashAnimationController);
  }

  @override
  void dispose() {
    _cameraService.dispose();
    _animationController.dispose();
    _flashAnimationController.dispose();
    super.dispose();
  }

  Future<void> _initializeCamera() async {
    try {
      final success = await _cameraService.initialize();
      setState(() {
        _isInitialized = success;
        if (!success) {
          _errorMessage = 'Não foi possível inicializar a câmera. Verifique as permissões.';
        }
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Erro ao inicializar câmera: \$e';
      });
    }
  }

  Future<void> _takePicture() async {
    if (!_isInitialized || _isTakingPhoto) return;

    setState(() {
      _isTakingPhoto = true;
    });

    try {
      // Flash effect
      await _flashAnimationController.forward();
      await _flashAnimationController.reverse();
      
      final imagePath = await _cameraService.takePicture(widget.plateNumber);
      
      if (imagePath != null) {
        // Save photo to storage
        await _storageService.saveNewPhoto(imagePath, widget.plateNumber);
        
        // Sync to Supabase in background (don't await to avoid blocking UI)
        _storageService.syncLocalPhotosToSupabase();
        
        if (mounted) {
          _showSuccessDialog(imagePath);
        }
      } else {
        _showError('Falha ao capturar a foto');
      }
    } catch (e) {
      _showError('Erro ao tirar foto: \$e');
    } finally {
      setState(() {
        _isTakingPhoto = false;
      });
    }
  }

  Future<void> _switchCamera() async {
    if (_cameraService.cameras.length < 2) return;
    await _cameraService.switchCamera();
    setState(() {});
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Theme.of(context).colorScheme.error,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccessDialog(String imagePath) {
    final theme = Theme.of(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.borderRadius),
        ),
        title: Row(
          children: [
            Icon(
              Icons.check_circle,
              color: theme.colorScheme.tertiary,
            ),
            const SizedBox(width: AppConstants.smallPadding),
            const Text('Foto Capturada!'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Placa: \${widget.plateNumber}'),
            const SizedBox(height: AppConstants.smallPadding),
            Text(
              'Foto salva localmente e sendo enviada para o Google Drive.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              Navigator.of(context).pop(true); // Return to home
            },
            child: const Text('Continuar'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.of(context).pop(); // Close dialog
              // Stay on camera screen for more photos
            },
            child: const Text('Tirar Outra'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;
    
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera Preview
          if (_isInitialized && _cameraService.controller != null)
            SizedBox(
              width: size.width,
              height: size.height,
              child: CameraPreview(_cameraService.controller!),
            )
          else if (_errorMessage != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(AppConstants.largePadding),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.camera_alt_outlined,
                      size: 64,
                      color: Colors.white.withValues(alpha: 0.7),
                    ),
                    const SizedBox(height: AppConstants.defaultPadding),
                    Text(
                      _errorMessage!,
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: AppConstants.largePadding),
                    FilledButton(
                      onPressed: _initializeCamera,
                      child: const Text('Tentar Novamente'),
                    ),
                  ],
                ),
              ),
            )
          else
            const Center(
              child: CircularProgressIndicator(
                color: Colors.white,
              ),
            ),

          // Flash Overlay
          if (_isInitialized)
            FadeTransition(
              opacity: _flashAnimation,
              child: Container(
                width: size.width,
                height: size.height,
                color: Colors.white,
              ),
            ),

          // Top Bar
          SafeArea(
            child: Container(
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.7),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(
                      Icons.arrow_back,
                      color: Colors.white,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: Colors.black.withValues(alpha: 0.3),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppConstants.defaultPadding,
                      vertical: AppConstants.smallPadding,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.7),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.plateNumber,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  if (_cameraService.cameras.length > 1)
                    IconButton(
                      onPressed: _switchCamera,
                      icon: const Icon(
                        Icons.flip_camera_android,
                        color: Colors.white,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black.withValues(alpha: 0.3),
                      ),
                    ),
                ],
              ),
            ),
          ),

          // Bottom Bar
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(AppConstants.largePadding),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.7),
                    Colors.transparent,
                  ],
                ),
              ),
              child: SafeArea(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Gallery Button
                    IconButton(
                      onPressed: () {
                        // TODO: Open gallery or recent photos
                      },
                      icon: const Icon(
                        Icons.photo_library,
                        color: Colors.white,
                        size: 28,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black.withValues(alpha: 0.3),
                        fixedSize: const Size(56, 56),
                      ),
                    ),
                    
                    // Capture Button
                    ScaleTransition(
                      scale: _scaleAnimation,
                      child: GestureDetector(
                        onTapDown: (_) => _animationController.forward(),
                        onTapUp: (_) => _animationController.reverse(),
                        onTapCancel: () => _animationController.reverse(),
                        onTap: _isInitialized ? _takePicture : null,
                        child: Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            color: _isTakingPhoto 
                                ? theme.colorScheme.secondary 
                                : theme.colorScheme.primary,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white,
                              width: 3,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: theme.colorScheme.primary.withValues(alpha: 0.3),
                                blurRadius: 10,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: _isTakingPhoto
                              ? const CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 3,
                                )
                              : const Icon(
                                  Icons.camera_alt,
                                  color: Colors.white,
                                  size: 32,
                                ),
                        ),
                      ),
                    ),
                    
                    // Settings/Flash Button
                    IconButton(
                      onPressed: () {
                        // TODO: Toggle flash or settings
                      },
                      icon: const Icon(
                        Icons.flash_off,
                        color: Colors.white,
                        size: 28,
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor: Colors.black.withValues(alpha: 0.3),
                        fixedSize: const Size(56, 56),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Camera Guidelines Overlay
          if (_isInitialized)
            Positioned.fill(
              child: CustomPaint(
                painter: CameraGuidelinesPainter(
                  color: Colors.white.withValues(alpha: 0.3),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class CameraGuidelinesPainter extends CustomPainter {
  final Color color;
  
  CameraGuidelinesPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1;

    // Draw center rectangle for plate positioning
    final rect = Rect.fromCenter(
      center: Offset(size.width / 2, size.height / 2),
      width: size.width * 0.8,
      height: size.height * 0.2,
    );
    
    canvas.drawRect(rect, paint);
    
    // Draw corner indicators
    final cornerLength = 30.0;
    final corners = [
      rect.topLeft,
      rect.topRight,
      rect.bottomLeft,
      rect.bottomRight,
    ];
    
    for (final corner in corners) {
      // Horizontal lines
      canvas.drawLine(
        corner,
        corner + Offset(cornerLength * (corner == rect.topRight || corner == rect.bottomRight ? -1 : 1), 0),
        paint,
      );
      // Vertical lines
      canvas.drawLine(
        corner,
        corner + Offset(0, cornerLength * (corner == rect.bottomLeft || corner == rect.bottomRight ? -1 : 1)),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}