import 'package:flutter/material.dart';
import 'package:placacerta/services/auth_service.dart';
import 'package:placacerta/services/storage_service.dart';
import 'package:placacerta/models/plate_photo.dart';
import 'package:placacerta/widgets/custom_button.dart';
import 'package:placacerta/widgets/plate_input_field.dart';
import 'package:placacerta/utils/constants.dart';
import 'package:placacerta/utils/validators.dart';
import 'package:placacerta/screens/camera_screen.dart';
import 'package:placacerta/screens/photo_gallery_screen.dart';
import 'package:placacerta/screens/login_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final TextEditingController _plateController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final AuthService _authService = AuthService();
  final StorageService _storageService = StorageService();
  
  List<PlatePhoto> _recentPhotos = [];
  bool _isLoading = false;
  String _userDisplayName = 'Usuário';
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _initializeServices();
    _loadRecentPhotos();
    
    _animationController = AnimationController(
      duration: AppConstants.normalAnimation,
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _plateController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _initializeServices() async {
    await _authService.initialize();
    if (!_authService.isSignedIn && mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    } else {
      // Load user profile
      await _loadUserProfile();
    }
  }

  Future<void> _loadUserProfile() async {
    try {
      final userProfile = await _authService.getUserProfile();
      if (userProfile != null && mounted) {
        setState(() {
          _userDisplayName = userProfile['display_name'] ?? 'Usuário';
        });
      }
    } catch (e) {
      print('Erro ao carregar perfil do usuário: $e');
    }
  }

  Future<void> _loadRecentPhotos() async {
    final photos = await _storageService.loadSavedPhotos();
    setState(() {
      _recentPhotos = photos.take(3).toList();
    });
  }

  Future<void> _openCamera() async {
    if (!_formKey.currentState!.validate()) return;

    final plateNumber = PlateValidator.formatPlate(_plateController.text);
    
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (context) => CameraScreen(plateNumber: plateNumber),
      ),
    );

    if (result == true) {
      _plateController.clear();
      _loadRecentPhotos();
    }
  }

  Future<void> _logout() async {
    await _authService.signOut();
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    }
  }

  Future<void> _showUserInfo() async {
    final user = _authService.currentUser;
    if (user == null) return;

    final userProfile = await _authService.getUserProfile();
    final stats = await _storageService.getPhotoStats();

    if (!mounted) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Informações do Usuário'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Email: ${user.email ?? 'N/A'}'),
            const SizedBox(height: 8),
            Text('Nome: ${userProfile?['display_name'] ?? 'Usuário'}'),
            const Divider(),
            Text('Total de fotos: ${stats['total']}'),
            Text('Sincronizadas: ${stats['uploaded']}'),
            Text('Apenas local: ${stats['local_only']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await _syncPhotos();
            },
            child: const Text('Sincronizar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  Future<void> _syncPhotos() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await _storageService.syncLocalPhotosToSupabase();
      await _loadRecentPhotos(); // Refresh the list
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Fotos sincronizadas com sucesso!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao sincronizar: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          AppConstants.appName,
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _showUserInfo,
            icon: Icon(
              Icons.account_circle,
              color: theme.colorScheme.onSurface,
            ),
            tooltip: 'Perfil do Usuário',
          ),
          IconButton(
            onPressed: _logout,
            icon: Icon(
              Icons.logout,
              color: theme.colorScheme.onSurface,
            ),
            tooltip: 'Sair',
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppConstants.largePadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(AppConstants.largePadding),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      theme.colorScheme.primary,
                      theme.colorScheme.secondary,
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(AppConstants.borderRadius),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Olá, $_userDisplayName!',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: AppConstants.smallPadding),
                    Text(
                      'Pronto para capturar mais uma placa?',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: Colors.white.withValues(alpha: 0.9),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: AppConstants.largePadding * 2),

              // Plate Input Section
              Text(
                'Digite a Placa',
                style: theme.textTheme.titleLarge?.copyWith(
                  color: theme.colorScheme.onSurface,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: AppConstants.defaultPadding),
              
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    PlateInputField(
                      controller: _plateController,
                      onChanged: () => setState(() {}),
                    ),
                    const SizedBox(height: AppConstants.largePadding),
                    SizedBox(
                      width: double.infinity,
                      child: CustomButton(
                        text: 'Abrir Câmera',
                        icon: Icons.camera_alt,
                        onPressed: _plateController.text.isNotEmpty ? _openCamera : null,
                        isLoading: _isLoading,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: AppConstants.largePadding * 2),

              // Recent Photos Section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Fotos Recentes',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: theme.colorScheme.onSurface,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => const PhotoGalleryScreen(),
                        ),
                      );
                    },
                    child: Text(
                      'Ver Todas',
                      style: TextStyle(color: theme.colorScheme.primary),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: AppConstants.defaultPadding),

              // Recent Photos Grid
              _recentPhotos.isEmpty
                  ? _buildEmptyState(context)
                  : _buildRecentPhotosGrid(context),

              const SizedBox(height: AppConstants.largePadding),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: CustomButton(
                      text: 'Galeria',
                      icon: Icons.photo_library,
                      isPrimary: false,
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => const PhotoGalleryScreen(),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: AppConstants.defaultPadding),
                  Expanded(
                    child: CustomButton(
                      text: 'Sincronizar',
                      icon: Icons.cloud_sync,
                      isPrimary: false,
                      onPressed: () async {
                        setState(() => _isLoading = true);
                        await _storageService.syncLocalPhotosToSupabase();
                        setState(() => _isLoading = false);
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Sincronização concluída!')),
                          );
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppConstants.largePadding * 2),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceVariant.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(AppConstants.borderRadius),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.photo_camera_back,
            size: 64,
            color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
          ),
          const SizedBox(height: AppConstants.defaultPadding),
          Text(
            'Nenhuma foto ainda',
            style: theme.textTheme.titleMedium?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
            ),
          ),
          const SizedBox(height: AppConstants.smallPadding),
          Text(
            'Digite uma placa e tire sua primeira foto!',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentPhotosGrid(BuildContext context) {
    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _recentPhotos.length,
        itemBuilder: (context, index) {
          final photo = _recentPhotos[index];
          return _buildPhotoCard(context, photo);
        },
      ),
    );
  }

  Widget _buildPhotoCard(BuildContext context, PlatePhoto photo) {
    final theme = Theme.of(context);
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: AppConstants.defaultPadding),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(AppConstants.borderRadius),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.image,
            size: 40,
            color: theme.colorScheme.primary,
          ),
          const SizedBox(height: AppConstants.smallPadding),
          Text(
            photo.plateNumber,
            style: theme.textTheme.labelMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.colorScheme.onSurface,
            ),
          ),
          Text(
            '\${photo.timestamp.day}/\${photo.timestamp.month}',
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }
}