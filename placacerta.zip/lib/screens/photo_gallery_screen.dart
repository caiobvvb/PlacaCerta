import 'package:flutter/material.dart';
import 'dart:io';
import 'package:placacerta/services/storage_service.dart';
import 'package:placacerta/models/plate_photo.dart';
import 'package:placacerta/utils/constants.dart';

class PhotoGalleryScreen extends StatefulWidget {
  const PhotoGalleryScreen({super.key});

  @override
  State<PhotoGalleryScreen> createState() => _PhotoGalleryScreenState();
}

class _PhotoGalleryScreenState extends State<PhotoGalleryScreen> with TickerProviderStateMixin {
  final StorageService _storageService = StorageService();
  
  List<PlatePhoto> _photos = [];
  List<PlatePhoto> _filteredPhotos = [];
  bool _isLoading = true;
  String _searchQuery = '';
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _loadPhotos();
    
    _animationController = AnimationController(
      duration: AppConstants.normalAnimation,
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadPhotos() async {
    try {
      final photos = await _storageService.loadSavedPhotos();
      setState(() {
        _photos = photos.reversed.toList(); // Show newest first
        _filteredPhotos = _photos;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _filterPhotos(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _filteredPhotos = _photos;
      } else {
        _filteredPhotos = _photos
            .where((photo) => photo.plateNumber.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  Future<void> _deletePhoto(PlatePhoto photo) async {
    final confirmed = await _showDeleteConfirmation(photo);
    if (confirmed == true) {
      await _storageService.deletePhoto(photo);
      _loadPhotos();
    }
  }

  Future<bool?> _showDeleteConfirmation(PlatePhoto photo) {
    final theme = Theme.of(context);
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppConstants.borderRadius),
        ),
        title: const Text('Excluir Foto'),
        content: Text('Deseja realmente excluir a foto da placa \${photo.plateNumber}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor: theme.colorScheme.error,
            ),
            child: Text(
              'Excluir',
              style: TextStyle(color: theme.colorScheme.onError),
            ),
          ),
        ],
      ),
    );
  }

  void _showPhotoDetails(PlatePhoto photo) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _PhotoDetailsBottomSheet(photo: photo),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: Icon(
            Icons.arrow_back,
            color: theme.colorScheme.onSurface,
          ),
        ),
        title: Text(
          'Galeria de Fotos',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () async {
              await _storageService.syncLocalPhotosToSupabase();
              _loadPhotos();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Sincronização concluída!')),
                );
              }
            },
            icon: Icon(
              Icons.cloud_sync,
              color: theme.colorScheme.onSurface,
            ),
            tooltip: 'Sincronizar',
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            // Search Bar
            Padding(
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              child: TextField(
                onChanged: _filterPhotos,
                decoration: InputDecoration(
                  hintText: 'Buscar por placa...',
                  prefixIcon: Icon(
                    Icons.search,
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                  filled: true,
                  fillColor: theme.colorScheme.surface.withValues(alpha: 0.3),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(AppConstants.borderRadius),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: AppConstants.defaultPadding,
                    vertical: AppConstants.smallPadding,
                  ),
                ),
              ),
            ),

            // Stats Bar
            Container(
              margin: const EdgeInsets.symmetric(horizontal: AppConstants.defaultPadding),
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
                    theme.colorScheme.secondaryContainer.withValues(alpha: 0.3),
                  ],
                ),
                borderRadius: BorderRadius.circular(AppConstants.borderRadius),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildStatItem(
                    context,
                    'Total',
                    _photos.length.toString(),
                    Icons.photo_library,
                  ),
                  _buildStatItem(
                    context,
                    'Sincronizadas',
                    _photos.where((p) => p.isUploaded).length.toString(),
                    Icons.cloud_done,
                  ),
                  _buildStatItem(
                    context,
                    'Locais',
                    _photos.where((p) => !p.isUploaded).length.toString(),
                    Icons.phone_android,
                  ),
                ],
              ),
            ),

            const SizedBox(height: AppConstants.defaultPadding),

            // Photos Grid
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _filteredPhotos.isEmpty
                      ? _buildEmptyState(context)
                      : _buildPhotosGrid(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(BuildContext context, String label, String value, IconData icon) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Icon(
          icon,
          color: theme.colorScheme.primary,
          size: 24,
        ),
        const SizedBox(height: AppConstants.smallPadding),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.onSurface,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppConstants.largePadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _searchQuery.isEmpty ? Icons.photo_camera_back : Icons.search_off,
              size: 64,
              color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppConstants.defaultPadding),
            Text(
              _searchQuery.isEmpty 
                  ? 'Nenhuma foto encontrada'
                  : 'Nenhuma placa encontrada para "\$_searchQuery"',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
              ),
            ),
            const SizedBox(height: AppConstants.smallPadding),
            Text(
              _searchQuery.isEmpty 
                  ? 'Tire sua primeira foto para vê-la aqui!'
                  : 'Tente buscar por outra placa',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotosGrid(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(AppConstants.defaultPadding),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: AppConstants.defaultPadding,
        mainAxisSpacing: AppConstants.defaultPadding,
        childAspectRatio: 0.8,
      ),
      itemCount: _filteredPhotos.length,
      itemBuilder: (context, index) {
        final photo = _filteredPhotos[index];
        return _buildPhotoCard(context, photo);
      },
    );
  }

  Widget _buildPhotoCard(BuildContext context, PlatePhoto photo) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: () => _showPhotoDetails(photo),
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(AppConstants.borderRadius),
          border: Border.all(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
          ),
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Image Preview
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface.withValues(alpha: 0.3),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(AppConstants.borderRadius),
                    topRight: Radius.circular(AppConstants.borderRadius),
                  ),
                ),
                child: File(photo.imagePath).existsSync()
                    ? ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(AppConstants.borderRadius),
                          topRight: Radius.circular(AppConstants.borderRadius),
                        ),
                        child: Image.file(
                          File(photo.imagePath),
                          fit: BoxFit.cover,
                        ),
                      )
                    : Icon(
                        Icons.broken_image,
                        size: 48,
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
                      ),
              ),
            ),
            
            // Photo Info
            Padding(
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        photo.plateNumber,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: theme.colorScheme.onSurface,
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (photo.isUploaded)
                            Icon(
                              Icons.cloud_done,
                              size: 16,
                              color: theme.colorScheme.tertiary,
                            ),
                          const SizedBox(width: AppConstants.smallPadding),
                          GestureDetector(
                            onTap: () => _deletePhoto(photo),
                            child: Icon(
                              Icons.delete_outline,
                              size: 16,
                              color: theme.colorScheme.error,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: AppConstants.smallPadding),
                  Text(
                    '\${photo.timestamp.day}/\${photo.timestamp.month}/\${photo.timestamp.year} - \${photo.timestamp.hour}:\${photo.timestamp.minute.toString().padLeft(2, "0")}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PhotoDetailsBottomSheet extends StatelessWidget {
  final PlatePhoto photo;

  const _PhotoDetailsBottomSheet({required this.photo});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final size = MediaQuery.of(context).size;

    return Container(
      height: size.height * 0.8,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(AppConstants.borderRadius * 2),
          topRight: Radius.circular(AppConstants.borderRadius * 2),
        ),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: const EdgeInsets.only(top: AppConstants.defaultPadding),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          const SizedBox(height: AppConstants.defaultPadding),

          // Image
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(AppConstants.defaultPadding),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(AppConstants.borderRadius),
              ),
              child: File(photo.imagePath).existsSync()
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(AppConstants.borderRadius),
                      child: Image.file(
                        File(photo.imagePath),
                        fit: BoxFit.contain,
                      ),
                    )
                  : Center(
                      child: Icon(
                        Icons.broken_image,
                        size: 64,
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
                      ),
                    ),
            ),
          ),

          // Details
          Padding(
            padding: const EdgeInsets.all(AppConstants.defaultPadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Placa: \${photo.plateNumber}',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Icon(
                      photo.isUploaded ? Icons.cloud_done : Icons.phone_android,
                      color: photo.isUploaded ? theme.colorScheme.tertiary : theme.colorScheme.secondary,
                    ),
                  ],
                ),
                const SizedBox(height: AppConstants.smallPadding),
                Text(
                  'Capturada em \${photo.timestamp.day}/\${photo.timestamp.month}/\${photo.timestamp.year} às \${photo.timestamp.hour}:\${photo.timestamp.minute.toString().padLeft(2, "0")}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
                const SizedBox(height: AppConstants.smallPadding),
                Text(
                  photo.isUploaded ? 'Sincronizada com Google Drive' : 'Armazenada apenas localmente',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}