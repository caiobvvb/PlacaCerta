import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:placacerta/supabase/supabase_config.dart';
import 'package:placacerta/utils/constants.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  User? get currentUser => SupabaseAuth.currentUser;
  bool get isSignedIn => SupabaseAuth.isAuthenticated;
  String? get currentUserEmail => currentUser?.email;

  // Get auth state changes stream
  Stream<AuthState> get authStateChanges => SupabaseAuth.authStateChanges;

  Future<void> initialize() async {
    // Supabase auth is automatically initialized when SupabaseConfig.initialize() is called
    // Check if we have a valid session
    try {
      final session = SupabaseConfig.client.auth.currentSession;
      if (session != null && currentUser != null) {
        // User is already authenticated
        await _createOrUpdateUserProfile(currentUser!);
      }
    } catch (e) {
      print('Erro ao inicializar AuthService: $e');
    }
  }

  Future<User?> signInWithGoogle() async {
    try {
      // For now, we'll simulate Google sign-in with email/password
      // In a real app, you would implement proper Google OAuth flow
      
      // Demo user for testing
      const demoEmail = 'demo@placacerta.com';
      const demoPassword = 'demo123456';
      
      AuthResponse response;
      
      try {
        // Try to sign in first
        response = await SupabaseAuth.signIn(
          email: demoEmail,
          password: demoPassword,
        );
      } catch (signInError) {
        // If sign in fails, try to sign up
        response = await SupabaseAuth.signUp(
          email: demoEmail,
          password: demoPassword,
          userData: {
            'display_name': 'Usuário Demo',
            'provider': 'google',
          },
        );
      }

      if (response.user != null) {
        await _createOrUpdateUserProfile(response.user!);
        return response.user;
      }
      
      return null;
    } catch (e) {
      print('Erro ao fazer login: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      await SupabaseAuth.signOut();
      
      // Clear local preferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
    } catch (e) {
      print('Erro ao fazer logout: $e');
      rethrow;
    }
  }

  Future<void> _createOrUpdateUserProfile(User user) async {
    try {
      // Check if user profile already exists
      final existingUser = await SupabaseService.selectSingle(
        'users',
        filters: {'id': user.id},
      );

      if (existingUser == null) {
        // Create new user profile
        await SupabaseService.insert('users', {
          'id': user.id,
          'email': user.email ?? '',
          'display_name': user.userMetadata?['display_name'] ?? 'Usuário',
          'photo_url': user.userMetadata?['photo_url'],
          'provider': user.userMetadata?['provider'] ?? 'email',
        });
      } else {
        // Update existing user profile
        await SupabaseService.update(
          'users',
          {
            'display_name': user.userMetadata?['display_name'] ?? existingUser['display_name'],
            'photo_url': user.userMetadata?['photo_url'] ?? existingUser['photo_url'],
            'updated_at': DateTime.now().toIso8601String(),
          },
          filters: {'id': user.id},
        );
      }
    } catch (e) {
      print('Erro ao criar/atualizar perfil do usuário: $e');
      // Don't throw error to avoid breaking auth flow
    }
  }

  Future<Map<String, dynamic>?> getUserProfile() async {
    if (!isSignedIn || currentUser == null) return null;

    try {
      return await SupabaseService.selectSingle(
        'users',
        filters: {'id': currentUser!.id},
      );
    } catch (e) {
      print('Erro ao buscar perfil do usuário: $e');
      return null;
    }
  }
}

// Legacy MockUser class for backwards compatibility
class MockUser {
  final String email;
  final String displayName;
  final String? photoUrl;

  MockUser({
    required this.email,
    required this.displayName,
    this.photoUrl,
  });
}