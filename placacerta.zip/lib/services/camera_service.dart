import 'dart:io';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:placacerta/utils/constants.dart';

class CameraService {
  static final CameraService _instance = CameraService._internal();
  factory CameraService() => _instance;
  CameraService._internal();

  List<CameraDescription> _cameras = [];
  CameraController? _controller;
  bool _isInitialized = false;

  List<CameraDescription> get cameras => _cameras;
  CameraController? get controller => _controller;
  bool get isInitialized => _isInitialized;

  Future<bool> initialize() async {
    try {
      // Check camera permission
      final cameraPermission = await Permission.camera.status;
      if (!cameraPermission.isGranted) {
        final result = await Permission.camera.request();
        if (!result.isGranted) {
          return false;
        }
      }

      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        return false;
      }

      _controller = CameraController(
        _cameras[0],
        ResolutionPreset.high,
        enableAudio: false,
      );

      await _controller!.initialize();
      _isInitialized = true;
      return true;
    } catch (e) {
      print('Erro ao inicializar câmera: \$e');
      return false;
    }
  }

  Future<String?> takePicture(String plateNumber) async {
    if (!_isInitialized || _controller == null) {
      return null;
    }

    try {
      // Get the app's documents directory
      final Directory appDir = await getApplicationDocumentsDirectory();
      final String dirPath = '\${appDir.path}/PlacaCerta';
      await Directory(dirPath).create(recursive: true);

      // Create filename with plate number and timestamp
      final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final String fileName = '\${plateNumber}_\$timestamp.jpg';
      final String filePath = '\$dirPath/\$fileName';

      // Take the picture
      final XFile photo = await _controller!.takePicture();
      
      // Move the file to our app directory
      final File newFile = File(filePath);
      await File(photo.path).copy(newFile.path);
      await File(photo.path).delete(); // Clean up temp file

      return newFile.path;
    } catch (e) {
      print('Erro ao tirar foto: \$e');
      return null;
    }
  }

  Future<void> switchCamera() async {
    if (_cameras.length < 2) return;

    try {
      final currentIndex = _cameras.indexOf(_controller!.description);
      final nextIndex = (currentIndex + 1) % _cameras.length;
      
      await _controller?.dispose();
      
      _controller = CameraController(
        _cameras[nextIndex],
        ResolutionPreset.high,
        enableAudio: false,
      );
      
      await _controller!.initialize();
    } catch (e) {
      print('Erro ao trocar câmera: \$e');
    }
  }

  Future<void> dispose() async {
    await _controller?.dispose();
    _controller = null;
    _isInitialized = false;
  }

  Future<bool> requestPermissions() async {
    final cameraPermission = await Permission.camera.request();
    final storagePermission = await Permission.storage.request();
    
    return cameraPermission.isGranted && storagePermission.isGranted;
  }
}