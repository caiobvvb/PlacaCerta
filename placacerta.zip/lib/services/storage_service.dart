import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:placacerta/models/plate_photo.dart';
import 'package:placacerta/services/auth_service.dart';
import 'package:placacerta/supabase/supabase_config.dart';
import 'package:placacerta/utils/constants.dart';

class StorageService {
  static final StorageService _instance = StorageService._internal();
  factory StorageService() => _instance;
  StorageService._internal();

  final AuthService _authService = AuthService();

  /// Load photos from Supabase database for the current user
  Future<List<PlatePhoto>> loadSavedPhotos() async {
    try {
      if (!_authService.isSignedIn || _authService.currentUser == null) {
        return [];
      }

      final data = await SupabaseService.select(
        'plate_photos',
        filters: {'user_id': _authService.currentUser!.id},
        orderBy: 'captured_at',
        ascending: false,
      );

      return data.map((json) => PlatePhoto.fromSupabase(json)).toList();
    } catch (e) {
      print('Erro ao carregar fotos do Supabase: $e');
      // Fallback to local storage
      return await _loadLocalPhotos();
    }
  }

  /// Load photos from local SharedPreferences (fallback)
  Future<List<PlatePhoto>> _loadLocalPhotos() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? photosJson = prefs.getString(AppConstants.photosListKey);
      
      if (photosJson != null) {
        final List<dynamic> photosList = jsonDecode(photosJson);
        return photosList.map((json) => PlatePhoto.fromJson(json)).toList();
      }
    } catch (e) {
      print('Erro ao carregar fotos locais: $e');
    }
    return [];
  }

  /// Save photos list to local SharedPreferences (backup)
  Future<void> _saveLocalPhotos(List<PlatePhoto> photos) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String photosJson = jsonEncode(photos.map((photo) => photo.toJson()).toList());
      await prefs.setString(AppConstants.photosListKey, photosJson);
    } catch (e) {
      print('Erro ao salvar fotos localmente: $e');
    }
  }

  /// Save a new photo to Supabase database and optionally upload file
  Future<PlatePhoto> saveNewPhoto(String imagePath, String plateNumber) async {
    final photo = PlatePhoto(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      plateNumber: plateNumber,
      imagePath: imagePath,
      timestamp: DateTime.now(),
      isSavedLocally: true,
    );

    try {
      if (_authService.isSignedIn && _authService.currentUser != null) {
        // Save to Supabase database
        await _savePhotoToSupabase(photo);
        
        // Try to upload the actual image file
        await _uploadPhotoFile(photo);
      } else {
        // Save locally as fallback
        await _savePhotoLocally(photo);
      }
    } catch (e) {
      print('Erro ao salvar foto: $e');
      // Always save locally as backup
      await _savePhotoLocally(photo);
    }

    return photo;
  }

  /// Save photo metadata to Supabase database
  Future<void> _savePhotoToSupabase(PlatePhoto photo) async {
    if (!_authService.isSignedIn || _authService.currentUser == null) {
      throw Exception('User not authenticated');
    }

    try {
      final data = await SupabaseService.insert('plate_photos', {
        'id': photo.id,
        'user_id': _authService.currentUser!.id,
        'plate_number': photo.plateNumber,
        'image_path': photo.imagePath,
        'captured_at': photo.timestamp.toIso8601String(),
        'is_saved_locally': photo.isSavedLocally,
        'is_uploaded': photo.isUploaded,
        'drive_file_id': photo.driveFileId,
      });

      print('Foto salva no Supabase: ${data.first['id']}');
    } catch (e) {
      print('Erro ao salvar foto no Supabase: $e');
      rethrow;
    }
  }

  /// Upload photo file to Supabase Storage
  Future<void> _uploadPhotoFile(PlatePhoto photo) async {
    try {
      final file = File(photo.imagePath);
      if (!await file.exists()) {
        print('Arquivo de imagem não encontrado: ${photo.imagePath}');
        return;
      }

      final fileBytes = await file.readAsBytes();
      final fileName = 'plate_photos/${_authService.currentUser!.id}/${photo.id}.jpg';

      // Upload to Supabase Storage
      await SupabaseConfig.client.storage
          .from('plate-images')
          .uploadBinary(fileName, fileBytes);

      // Get public URL
      final imageUrl = SupabaseConfig.client.storage
          .from('plate-images')
          .getPublicUrl(fileName);

      // Update photo record with image URL
      await SupabaseService.update(
        'plate_photos',
        {
          'image_url': imageUrl,
          'is_uploaded': true,
        },
        filters: {'id': photo.id},
      );

      print('Arquivo enviado para Supabase Storage: $fileName');
    } catch (e) {
      print('Erro ao enviar arquivo para Supabase Storage: $e');
      // Don't rethrow - photo metadata is still saved
    }
  }

  /// Save photo locally as fallback
  Future<void> _savePhotoLocally(PlatePhoto photo) async {
    final photos = await _loadLocalPhotos();
    photos.add(photo);
    await _saveLocalPhotos(photos);
  }

  /// Delete a photo from both Supabase and local storage
  Future<void> deletePhoto(PlatePhoto photo) async {
    try {
      if (_authService.isSignedIn && _authService.currentUser != null) {
        // Delete from Supabase database
        await SupabaseService.delete(
          'plate_photos',
          filters: {'id': photo.id},
        );

        // Delete from Supabase Storage if uploaded
        if (photo.isUploaded) {
          final fileName = 'plate_photos/${_authService.currentUser!.id}/${photo.id}.jpg';
          await SupabaseConfig.client.storage
              .from('plate-images')
              .remove([fileName]);
        }
      }

      // Also remove from local storage
      final localPhotos = await _loadLocalPhotos();
      localPhotos.removeWhere((p) => p.id == photo.id);
      await _saveLocalPhotos(localPhotos);

      // Delete local file if exists
      try {
        final file = File(photo.imagePath);
        if (await file.exists()) {
          await file.delete();
        }
      } catch (e) {
        print('Erro ao deletar arquivo local: $e');
      }
    } catch (e) {
      print('Erro ao deletar foto: $e');
      rethrow;
    }
  }

  /// Search photos by plate number
  Future<List<PlatePhoto>> searchPhotosByPlate(String plateNumber) async {
    try {
      if (_authService.isSignedIn && _authService.currentUser != null) {
        final data = await SupabaseService.select(
          'plate_photos',
          filters: {
            'user_id': _authService.currentUser!.id,
            'plate_number': plateNumber.toUpperCase(),
          },
          orderBy: 'captured_at',
          ascending: false,
        );

        return data.map((json) => PlatePhoto.fromSupabase(json)).toList();
      }
    } catch (e) {
      print('Erro ao buscar fotos por placa: $e');
    }

    // Fallback to local search
    final allPhotos = await _loadLocalPhotos();
    return allPhotos
        .where((photo) => photo.plateNumber.toUpperCase().contains(plateNumber.toUpperCase()))
        .toList();
  }

  /// Sync local photos to Supabase (useful after login)
  Future<void> syncLocalPhotosToSupabase() async {
    if (!_authService.isSignedIn || _authService.currentUser == null) {
      return;
    }

    try {
      final localPhotos = await _loadLocalPhotos();
      for (final photo in localPhotos) {
        try {
          await _savePhotoToSupabase(photo);
          await _uploadPhotoFile(photo);
        } catch (e) {
          print('Erro ao sincronizar foto ${photo.id}: $e');
          // Continue with other photos
        }
      }
      print('Sincronização de fotos concluída');
    } catch (e) {
      print('Erro na sincronização de fotos: $e');
    }
  }

  /// Get photo statistics
  Future<Map<String, int>> getPhotoStats() async {
    try {
      if (_authService.isSignedIn && _authService.currentUser != null) {
        final photos = await loadSavedPhotos();
        return {
          'total': photos.length,
          'uploaded': photos.where((p) => p.isUploaded).length,
          'local_only': photos.where((p) => !p.isUploaded).length,
        };
      }
    } catch (e) {
      print('Erro ao obter estatísticas: $e');
    }

    final localPhotos = await _loadLocalPhotos();
    return {
      'total': localPhotos.length,
      'uploaded': 0,
      'local_only': localPhotos.length,
    };
  }
}