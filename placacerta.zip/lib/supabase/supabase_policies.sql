-- Enable Row Level Security for all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE plate_photos ENABLE ROW LEVEL SECURITY;

-- Users table policies
-- Allow users to insert their own profile with any data (needed for signup)
CREATE POLICY "Users can insert their own profile" ON users
    FOR INSERT WITH CHECK (true);

-- Allow users to view their own profile
CREATE POLICY "Users can view their own profile" ON users
    FOR SELECT USING (auth.uid() = id);

-- Allow users to update their own profile
CREATE POLICY "Users can update their own profile" ON users
    FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Allow users to delete their own profile
CREATE POLICY "Users can delete their own profile" ON users
    FOR DELETE USING (auth.uid() = id);

-- Plate photos table policies
-- Allow authenticated users to insert their own plate photos
CREATE POLICY "Users can insert their own plate photos" ON plate_photos
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Allow users to view their own plate photos
CREATE POLICY "Users can view their own plate photos" ON plate_photos
    FOR SELECT USING (auth.uid() = user_id);

-- Allow users to update their own plate photos
CREATE POLICY "Users can update their own plate photos" ON plate_photos
    FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Allow users to delete their own plate photos
CREATE POLICY "Users can delete their own plate photos" ON plate_photos
    FOR DELETE USING (auth.uid() = user_id);