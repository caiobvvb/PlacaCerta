-- Enable UUID extension for generating unique identifiers
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table to store user profile information
-- This table has a foreign key to auth.users
CREATE TABLE users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    display_name TEXT,
    photo_url TEXT,
    provider TEXT DEFAULT 'google',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Plate photos table to store car plate capture data
CREATE TABLE plate_photos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plate_number TEXT NOT NULL,
    image_path TEXT NOT NULL,
    image_url TEXT,
    file_size INTEGER,
    mime_type TEXT DEFAULT 'image/jpeg',
    is_uploaded BOOLEAN DEFAULT false,
    is_saved_locally BOOLEAN DEFAULT false,
    drive_file_id TEXT,
    captured_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create indexes for better query performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_plate_photos_user_id ON plate_photos(user_id);
CREATE INDEX idx_plate_photos_plate_number ON plate_photos(plate_number);
CREATE INDEX idx_plate_photos_captured_at ON plate_photos(captured_at DESC);
CREATE INDEX idx_plate_photos_created_at ON plate_photos(created_at DESC);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc'::text, NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers to automatically update updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_plate_photos_updated_at BEFORE UPDATE ON plate_photos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();