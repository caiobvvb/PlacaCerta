class AppConstants {
  // App Info
  static const String appName = 'PlacaCerta';
  static const String appVersion = '1.0.0';
  
  // Storage Keys
  static const String userPrefsKey = 'user_preferences';
  static const String photosListKey = 'saved_photos';
  static const String isLoggedInKey = 'is_logged_in';
  static const String userDataKey = 'user_data';
  
  // Google Drive
  static const List<String> driveScopes = [
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/drive.readonly',
  ];
  
  // Camera Settings
  static const double maxImageWidth = 1920;
  static const double maxImageHeight = 1080;
  static const int imageQuality = 85;
  
  // UI Constants
  static const double defaultPadding = 16.0;
  static const double largePadding = 24.0;
  static const double smallPadding = 8.0;
  static const double borderRadius = 16.0;
  static const double buttonHeight = 56.0;
  
  // Animation Durations
  static const Duration fastAnimation = Duration(milliseconds: 200);
  static const Duration normalAnimation = Duration(milliseconds: 300);
  static const Duration slowAnimation = Duration(milliseconds: 500);
  
  // Messages
  static const String plateInputHint = 'Digite a placa (ABC-1234)';
  static const String cameraPermissionMessage = 'Permissão de câmera necessária';
  static const String storagePermissionMessage = 'Permissão de armazenamento necessária';
  static const String loginRequiredMessage = 'É necessário fazer login para continuar';
}