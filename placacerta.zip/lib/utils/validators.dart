class PlateValidator {
  // Brazilian license plate formats:
  // Old format: ABC-1234 (3 letters, hyphen, 4 numbers)
  // New format: ABC1D23 (3 letters, 1 number, 1 letter, 2 numbers - Mercosul)
  
  static final RegExp _oldFormatRegex = RegExp(r'^[A-Z]{3}-?\d{4}$');
  static final RegExp _newFormatRegex = RegExp(r'^[A-Z]{3}\d[A-Z]\d{2}$');
  
  static bool isValidBrazilianPlate(String plate) {
    if (plate.isEmpty) return false;
    
    String cleanPlate = plate.toUpperCase().replaceAll('-', '').trim();
    
    // Check old format (with or without hyphen)
    if (_oldFormatRegex.hasMatch(plate.toUpperCase()) || 
        _oldFormatRegex.hasMatch(cleanPlate)) {
      return true;
    }
    
    // Check new format (Mercosul)
    if (_newFormatRegex.hasMatch(cleanPlate)) {
      return true;
    }
    
    return false;
  }
  
  static String formatPlate(String plate) {
    String cleanPlate = plate.toUpperCase().replaceAll('-', '').replaceAll(' ', '');
    
    if (cleanPlate.length == 7) {
      // Check if it's old format (3 letters + 4 numbers)
      if (RegExp(r'^[A-Z]{3}\d{4}$').hasMatch(cleanPlate)) {
        return '${cleanPlate.substring(0, 3)}-${cleanPlate.substring(3)}';
      }
      // New format (Mercosul) - no hyphen needed
      return cleanPlate;
    }
    
    return plate.toUpperCase();
  }
  
  static String? validatePlate(String? value) {
    if (value == null || value.isEmpty) {
      return 'Por favor, digite uma placa';
    }
    
    if (!isValidBrazilianPlate(value)) {
      return 'Formato inválido. Use: ABC-1234 ou ABC1D23';
    }
    
    return null;
  }
}