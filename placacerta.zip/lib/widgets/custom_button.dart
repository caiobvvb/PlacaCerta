import 'package:flutter/material.dart';
import 'package:placacerta/utils/constants.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isPrimary;
  final IconData? icon;
  final Color? backgroundColor;
  final Color? textColor;
  final double? width;
  final double height;

  const CustomButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isPrimary = true,
    this.icon,
    this.backgroundColor,
    this.textColor,
    this.width,
    this.height = AppConstants.buttonHeight,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return AnimatedContainer(
      duration: AppConstants.fastAnimation,
      width: width,
      height: height,
      child: ElevatedButton.icon(
        onPressed: isLoading ? null : onPressed,
        icon: isLoading 
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: textColor ?? (isPrimary ? theme.colorScheme.onPrimary : theme.colorScheme.primary),
              ),
            )
          : icon != null 
            ? Icon(
                icon, 
                color: textColor ?? (isPrimary ? theme.colorScheme.onPrimary : theme.colorScheme.primary),
              )
            : const SizedBox.shrink(),
        label: Text(
          text,
          style: theme.textTheme.labelLarge?.copyWith(
            color: textColor ?? (isPrimary ? theme.colorScheme.onPrimary : theme.colorScheme.primary),
            fontWeight: FontWeight.w600,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor ?? (isPrimary ? theme.colorScheme.primary : Colors.transparent),
          foregroundColor: textColor ?? (isPrimary ? theme.colorScheme.onPrimary : theme.colorScheme.primary),
          elevation: isPrimary ? 2 : 0,
          side: isPrimary ? null : BorderSide(color: theme.colorScheme.primary, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppConstants.borderRadius),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: AppConstants.largePadding,
            vertical: AppConstants.defaultPadding,
          ),
        ),
      ),
    );
  }
}